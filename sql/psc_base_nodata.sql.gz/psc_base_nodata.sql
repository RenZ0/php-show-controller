-- phpMyAdmin SQL Dump
-- version 3.3.10deb1
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Lun 03 Février 2014 à 23:49
-- Version du serveur: 5.1.54
-- Version de PHP: 5.3.5-1ubuntu7.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `psc`
--

-- --------------------------------------------------------

--
-- Structure de la table `dmx_colors`
--

CREATE TABLE IF NOT EXISTS `dmx_colors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `colorname` varchar(20) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_value` varchar(20) NOT NULL,
  `position` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_engine`
--

CREATE TABLE IF NOT EXISTS `dmx_engine` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `freq_ms` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_fixture`
--

CREATE TABLE IF NOT EXISTS `dmx_fixture` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fixture_name` varchar(50) NOT NULL,
  `id_schema` int(3) NOT NULL,
  `patch` int(3) NOT NULL,
  `patch_after` int(3) NOT NULL,
  `univ` int(2) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_groups`
--

CREATE TABLE IF NOT EXISTS `dmx_groups` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `id_group` int(3) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_grpsum`
--

CREATE TABLE IF NOT EXISTS `dmx_grpsum` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `id_schema` int(3) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_preferences`
--

CREATE TABLE IF NOT EXISTS `dmx_preferences` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `lang` varchar(2) NOT NULL,
  `display_rgb` int(1) NOT NULL,
  `display_cmy` int(1) NOT NULL,
  `univ_qty` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_scenari`
--

CREATE TABLE IF NOT EXISTS `dmx_scenari` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_scenari` int(10) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_value` varchar(20) NOT NULL,
  `step` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_scenseq`
--

CREATE TABLE IF NOT EXISTS `dmx_scenseq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_scenari` int(10) NOT NULL,
  `stepname` varchar(50) NOT NULL,
  `hold` varchar(5) NOT NULL,
  `fade` varchar(5) NOT NULL,
  `position` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_scensum`
--

CREATE TABLE IF NOT EXISTS `dmx_scensum` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `scenari_name` varchar(50) NOT NULL,
  `id_fixture` int(3) NOT NULL,
  `reverse` int(1) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_schema`
--

CREATE TABLE IF NOT EXISTS `dmx_schema` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_schema` int(10) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_defvalue` varchar(20) NOT NULL,
  `ch_info` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `dmx_schsum`
--

CREATE TABLE IF NOT EXISTS `dmx_schsum` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `schema_name` varchar(255) NOT NULL,
  `nb_channels` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;
