-- phpMyAdmin SQL Dump
-- version 3.3.7deb5
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Ven 30 Décembre 2011 à 01:50
-- Version du serveur: 5.1.49
-- Version de PHP: 5.3.3-7+squeeze3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `dmx`
--

-- --------------------------------------------------------

--
-- Structure de la table `dmx_colors`
--

CREATE TABLE IF NOT EXISTS `dmx_colors` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `colorname` varchar(20) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_value` varchar(20) NOT NULL,
  `position` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Contenu de la table `dmx_colors`
--

INSERT INTO `dmx_colors` (`id`, `colorname`, `ch_name`, `ch_value`, `position`, `disabled`) VALUES
(1, '3200k', 'rgb', '240.240.210', 100, 0),
(2, '4000k', 'rgb', '250.250.236', 100, 0),
(3, '6500k', 'rgb', '255.255.255', 100, 0),
(4, 'Rouge', 'rgb', '255.0.0', 100, 0),
(5, 'Vert', 'rgb', '0.255.0', 100, 0),
(6, 'Bleu', 'rgb', '0.0.255', 100, 0),
(7, 'Cyan', 'rgb', '0.255.255', 100, 0),
(8, 'Magenta', 'rgb', '255.0.255', 100, 0),
(9, 'Jaune', 'rgb', '255.255.0', 100, 0);

-- --------------------------------------------------------

--
-- Structure de la table `dmx_engine`
--

CREATE TABLE IF NOT EXISTS `dmx_engine` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `freq_ms` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `dmx_engine`
--

INSERT INTO `dmx_engine` (`id`, `freq_ms`) VALUES
(1, '25');

-- --------------------------------------------------------

--
-- Structure de la table `dmx_fixture`
--

CREATE TABLE IF NOT EXISTS `dmx_fixture` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `fixture_name` varchar(50) NOT NULL,
  `id_schema` int(3) NOT NULL,
  `patch` int(3) NOT NULL,
  `patch_after` int(3) NOT NULL,
  `univ` int(2) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `dmx_fixture`
--


-- --------------------------------------------------------

--
-- Structure de la table `dmx_preferences`
--

CREATE TABLE IF NOT EXISTS `dmx_preferences` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `lang` varchar(2) NOT NULL,
  `display_rgb` int(1) NOT NULL,
  `display_cmy` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Contenu de la table `dmx_preferences`
--

INSERT INTO `dmx_preferences` (`id`, `lang`, `display_rgb`, `display_cmy`) VALUES
(1, 'en', 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `dmx_scenari`
--

CREATE TABLE IF NOT EXISTS `dmx_scenari` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_scenari` int(10) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_value` varchar(20) NOT NULL,
  `step` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `dmx_scenari`
--


-- --------------------------------------------------------

--
-- Structure de la table `dmx_scenseq`
--

CREATE TABLE IF NOT EXISTS `dmx_scenseq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_scenari` int(10) NOT NULL,
  `stepname` varchar(50) NOT NULL,
  `hold` varchar(5) NOT NULL,
  `fade` varchar(5) NOT NULL,
  `position` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `dmx_scenseq`
--


-- --------------------------------------------------------

--
-- Structure de la table `dmx_scensum`
--

CREATE TABLE IF NOT EXISTS `dmx_scensum` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `scenari_name` varchar(50) NOT NULL,
  `id_fixture` int(3) NOT NULL,
  `reverse` int(1) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Contenu de la table `dmx_scensum`
--


-- --------------------------------------------------------

--
-- Structure de la table `dmx_schema`
--

CREATE TABLE IF NOT EXISTS `dmx_schema` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `id_schema` int(10) NOT NULL,
  `ch_name` varchar(20) NOT NULL,
  `ch_defvalue` varchar(20) NOT NULL,
  `ch_info` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=104 ;

--
-- Contenu de la table `dmx_schema`
--

INSERT INTO `dmx_schema` (`id`, `id_schema`, `ch_name`, `ch_defvalue`, `ch_info`) VALUES
(1, 1, 'rgb1', '0.0.0', 'color'),
(2, 2, 'master1', '255', 'intensity'),
(3, 2, 'rgb1', '0.0.0', 'color'),
(4, 2, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(5, 2, 'fade1', '0', 'program 1-2-3-4-random-all (fade speed fast to slow) : 10-51-92-133-174-215'),
(6, 3, 'rgb1', '0.0.0', 'color'),
(7, 3, 'rgb2', '0.0.0', 'color'),
(8, 3, 'rgb3', '0.0.0', 'color'),
(9, 3, 'rgb4', '0.0.0', 'color'),
(10, 3, 'rgb5', '0.0.0', 'color'),
(11, 3, 'rgb6', '0.0.0', 'color'),
(12, 3, 'rgb7', '0.0.0', 'color'),
(13, 3, 'rgb8', '0.0.0', 'color'),
(14, 4, 'master1', '255', 'intensity'),
(15, 4, 'rgb1', '0.0.0', 'color'),
(16, 4, 'rgb2', '0.0.0', 'color'),
(17, 4, 'rgb3', '0.0.0', 'color'),
(18, 4, 'rgb4', '0.0.0', 'color'),
(19, 4, 'rgb5', '0.0.0', 'color'),
(20, 4, 'rgb6', '0.0.0', 'color'),
(21, 4, 'rgb7', '0.0.0', 'color'),
(22, 4, 'rgb8', '0.0.0', 'color'),
(23, 4, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(24, 4, 'fade1', '0', 'program 1-2-3-4-random-all (fade speed fast to slow) : 10-51-92-133-174-215'),
(25, 4, 'fx1', '0', 'pause time 10 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 136-180-189-198-207-216-225-234-243-252'),
(26, 5, 'master1', '255', 'intensity'),
(27, 5, 'rgb1', '0.0.0', 'color'),
(28, 5, 'white1', '0', 'white'),
(29, 5, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(30, 5, 'fade1', '0', 'program 1-2-3-4-random-all (fade speed fast to slow) : 10-51-92-133-174-215'),
(31, 5, 'fx1', '0', 'pause time 10 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 136-180-189-198-207-216-225-234-243-252'),
(32, 6, 'master1', '255', 'intensity'),
(33, 6, 'rgb1', '0.0.0', 'color'),
(34, 6, 'white1', '0', 'white'),
(35, 6, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(36, 6, 'line1-lower', '150', 'lower led line (bas) : 100-up / 200-down'),
(37, 6, 'line2-central', '150', 'central led line (milieu) : 100-up / 200-down'),
(38, 6, 'line3-upper', '150', 'upper led line (haut) : 100-up / 200-down'),
(39, 6, 'fade1', '0', 'program from 1 to 8 : 10-41-72-103-134-165-196-226'),
(40, 6, 'move1', '0', 'position from 1 to 6 = 10-20-40-60-80-100 ; automated mov from 1 to 5 = 120-147-174-201-228'),
(41, 6, 'fx1', '0', 'pause time 10 ; motors reset 136 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 171-180-189-198-207-216-225-234-243-252'),
(42, 7, 'master1', '255', 'intensity'),
(43, 7, 'rgb1-right', '0.0.0', 'color'),
(44, 7, 'white1', '0', 'white'),
(45, 7, 'rgb2-left', '0.0.0', 'color'),
(46, 7, 'white2', '0', 'white'),
(47, 7, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(48, 7, 'line1-lower', '150', 'lower led line (bas) : 100-up / 200-down'),
(49, 7, 'line2-central', '150', 'central led line (milieu) : 100-up / 200-down'),
(50, 7, 'line3-upper', '150', 'upper led line (haut) : 100-up / 200-down'),
(51, 7, 'fade1', '0', 'program from 1 to 8 : 10-41-72-103-134-165-196-226'),
(52, 7, 'move1', '0', 'position from 1 to 6 = 10-20-40-60-80-100 ; automated mov from 1 to 5 = 120-147-174-201-228'),
(53, 7, 'fx1', '0', 'pause time 10 ; motors reset 136 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 171-180-189-198-207-216-225-234-243-252'),
(54, 8, 'master1', '255', 'intensity'),
(55, 8, 'rgb1', '0.0.0', 'color'),
(56, 8, 'white1', '0', 'white'),
(57, 8, 'rgb2', '0.0.0', 'color'),
(58, 8, 'white2', '0', 'white'),
(59, 8, 'rgb3', '0.0.0', 'color'),
(60, 8, 'white3', '0', 'white'),
(61, 8, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(62, 8, 'line1-lower', '150', 'lower led line (bas) : 100-up / 200-down'),
(63, 8, 'line2-central', '150', 'central led line (milieu) : 100-up / 200-down'),
(64, 8, 'line3-upper', '150', 'upper led line (haut) : 100-up / 200-down'),
(65, 8, 'fade1', '0', 'program from 1 to 8 : 10-41-72-103-134-165-196-226'),
(66, 8, 'move1', '0', 'position from 1 to 6 = 10-20-40-60-80-100 ; automated mov from 1 to 5 = 120-147-174-201-228'),
(67, 8, 'fx1', '0', 'pause time 10 ; motors reset 136 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 171-180-189-198-207-216-225-234-243-252'),
(68, 9, 'master1', '255', 'intensity'),
(69, 9, 'rgb1', '0.0.0', 'color'),
(70, 9, 'white1', '0', 'white'),
(71, 9, 'rgb2', '0.0.0', 'color'),
(72, 9, 'white2', '0', 'white'),
(73, 9, 'rgb3', '0.0.0', 'color'),
(74, 9, 'white3', '0', 'white'),
(75, 9, 'rgb4', '0.0.0', 'color'),
(76, 9, 'white4', '0', 'white'),
(77, 9, 'rgb5', '0.0.0', 'color'),
(78, 9, 'white5', '0', 'white'),
(79, 9, 'rgb6', '0.0.0', 'color'),
(80, 9, 'white6', '0', 'white'),
(81, 9, 'strobe1', '0', 'speed - pulse_sc_fo - pulse_fc_so - random_sync - random_nonsync : slow to fast : 10-60-111-162-210'),
(82, 9, 'line1-lower', '150', 'lower led line (bas) : 100-up / 200-down'),
(83, 9, 'line2-central', '150', 'central led line (milieu) : 100-up / 200-down'),
(84, 9, 'line3-upper', '150', 'upper led line (haut) : 100-up / 200-down'),
(85, 9, 'fade1', '0', 'program from 1 to 8 : 10-41-72-103-134-165-196-226'),
(86, 9, 'move1', '0', 'position from 1 to 6 = 10-20-40-60-80-100 ; automated mov from 1 to 5 = 120-147-174-201-228'),
(87, 9, 'fx1', '0', 'pause time 10 ; motors reset 136 ; park - freq 1000-1500-2000-2500-3000-3500-4000-4500-5000 Hz : 171-180-189-198-207-216-225-234-243-252'),
(88, 10, 'pan1-X', '127', 'X axis'),
(89, 10, 'pan2-X', '0', 'X axis, fine'),
(90, 10, 'tilt1-Y', '127', 'Y axis'),
(91, 10, 'tilt2-Y', '0', 'Y axis, fine'),
(92, 10, 'move', '0', 'movement speed : fast - ultra fast - vector, tracking (fast to slow) - smooth : 0-11-26-128-248'),
(93, 10, 'master', '255', 'intensity'),
(94, 10, 'shutter', '255', 'shutter closed - open : 0-67-126-185-245 ; strobe speed - pulse_sc_fo - pulse_fc_so - random_nonsync : slow to fast : 10-69-128-188'),
(95, 10, 'zoom1', '0', 'from narrow 13° to wide beam 26° (2X) ; from narrow 18° to wide beam 42° (3X)'),
(96, 10, 'zoom2', '0', 'zoom 2X - 3X : 0-129'),
(97, 10, 'nothing', '0', 'nothing'),
(98, 10, 'fx_wheel', '0', 'effect 1-2-3 : 11-93-175'),
(99, 10, 'fx_rotation', '0', 'indexing through 360° - rotation decreasing speed - rotation reverse increasing speed  : 11-128-193'),
(100, 10, 'color_wheel', '0', 'white beam - color 1-2-3-4-5 : 0-6-15-23-31-39 ; positions - rainbow reverse (fast to slow) - rainbow (slow to fast) : 46-128-191'),
(101, 10, 'cmy', '255.255.255', 'color'),
(102, 10, 'zap', '0', 'zap sync strobe - zap - blackout : 11-31-250'),
(103, 10, 'reset', '0', 'lamp off - reset pantilt-allnobopt-allnobo-all - lcd off-on - lamp on  : 10-30-66-101-136-171-186-200');

-- --------------------------------------------------------

--
-- Structure de la table `dmx_schsum`
--

CREATE TABLE IF NOT EXISTS `dmx_schsum` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `schema_name` varchar(255) NOT NULL,
  `nb_channels` int(3) NOT NULL,
  `disabled` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Contenu de la table `dmx_schsum`
--

INSERT INTO `dmx_schsum` (`id`, `schema_name`, `nb_channels`, `disabled`) VALUES
(1, 'RGB', 3, 0),
(2, 'Coemar Regobox', 6, 0),
(3, 'Coemar CD288_24ch', 24, 0),
(4, 'Coemar CD288_28ch', 28, 0),
(5, 'Coemar StageLite_SC', 8, 0),
(6, 'Coemar StageLiteFX_12ch', 12, 0),
(7, 'Coemar StageLiteFX_16ch', 16, 0),
(8, 'Coemar StageLiteFX_20ch', 20, 0),
(9, 'Coemar StageLiteFX_32ch', 32, 0),
(10, 'Coemar Infinity_Wash_M', 18, 0);
